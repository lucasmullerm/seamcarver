import java.awt.Color;

public class SeamCarver {

	private Picture pic;
	private int[][] color;
	private int w;
	private int h;
	private boolean ready;

	public SeamCarver(Picture picture) { // create a seam carver object based on the given picture
		pic = new Picture(picture);
		h = picture.height();
		w = picture.width();
		color = new int[w][h];
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				color[x][y] = picture.get(x, y).getRGB();
			}
		}
		ready = true;
	}

	private void checkBounds(int x, int y) {
		if (x < 0 || y < 0 || x >= width() || y >= height())
			throw new java.lang.IndexOutOfBoundsException();
	}

	private void checkSeam(int[] seam) {
		if (seam == null) throw new java.lang.NullPointerException();
		if (seam.length != width())
			throw new java.lang.IllegalArgumentException();
		for (int i = 1; i < seam.length; i++) {
			if (Math.abs(seam[i] - seam[i - 1]) > 1)
				throw new java.lang.IllegalArgumentException();
		}
	}

	private void transpose() {
		int[][] t = new int[h][w];
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				t[y][x] = color[x][y];
			}
		}
		int aux = w;
		w = h;
		h = aux;
		color = t;
	}

	private static int red(int rgb) {
		int RED = 0xFF;
		return rgb & RED;
	}

	private static int green(int rgb) {
		int GREEN = 0xFF00;
		return (rgb & GREEN) >> 8;
	}

	private static int blue(int rgb) {
		int BLUE = 0xFF0000;
		return (rgb & BLUE) >> 16;
	}

	public Picture picture() { // current picture
		if (ready)	return pic;
		pic = new Picture(w, h);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				Color c = new Color(color[x][y]);
				pic.set(x, y, c);
			}
		}
		ready = true;
		return pic;
	}

	public int width() { // width of current picture
		return w;
	}

	public int height() { // height of current picture
		return h;
	}

	private double energy(int id) {
		int x = id / h;
		int y = id % h;
		return energy(x, y);
	}

	public double energy(int x, int y) { // energy of pixel at column x and row y
		checkBounds(x, y);
		if (x == 0 || y == 0 || x == width() - 1 || y == height() - 1) {
			return 3*(255*255);
		}
		int l = color[x - 1][y];
		int r = color[x + 1][y];
		int u = color[x][y - 1];
		int d = color[x][y + 1]; 
		double dx2 = 0;
		dx2 += (red(l) - red(r))*(red(l) - red(r));
		dx2 += (green(l) - green(r))*(green(l) - green(r));
		dx2 += (blue(l) - blue(r))*(blue(l) - blue(r));
		double dy2 = 0;
		dy2 += (red(u) - red(d))*(red(u) - red(d));
		dy2 += (green(u) - green(d))*(green(u) - green(d));
		dy2 += (blue(u) - blue(d))*(blue(u) - blue(d));
		return dx2 + dy2;
	}

	private void update(IndexMinPQ<Double> pq, int id, int current, double dist, int[] from) {
		double e = dist + energy(id);
		if (pq.contains(id)) {
			if (e < pq.keyOf(id)) {
				pq.decreaseKey(id, e);
				from[id] = current;
			}
		}
		else {
			pq.insert(id, e);
			from[id] = current;
		}
	}

	public int[] findHorizontalSeam() { // sequence of indices for horizontal seam
		IndexMinPQ<Double> pq = new IndexMinPQ<Double>(w*h);
		int[] from = new int[w*h];
		boolean[] visited = new boolean[w*h];
		for (int y = 0; y < h; y++) {
			pq.insert(y, energy(y));
			visited[y] = true;
		}
		int it;
		while (true) {
			double energy = pq.minKey();
			int current = pq.delMin();
			visited[current] = true;
			int x = current / h;
			int y = current % h;
			if (x == w - 1) {
				it = current;
				break;
			}
			if (!visited[(x+1)*h + y])
				update(pq, (x+1)*h + y, current, energy, from);
			if (y > 0 && !visited[(x+1)*h + y-1]) update(pq, (x+1)*h + y-1, current, energy, from);
			if (y < h - 1 && !visited[(x+1)*h + y+1]) update(pq, (x+1)*h + y+1, current, energy, from);
		}
		pq = null;
		visited = null;
		int[] seam = new int[w];
		for (int x = w - 1; x >= 0; x--) {
			seam[x] = it % h;
			it = from[it];
		}
		return seam;
	}

	public int[] findVerticalSeam() { // sequence of indices for vertical seam
		transpose();
		int[] seam = findHorizontalSeam();
		transpose();
		return seam;
	}

	public void removeHorizontalSeam(int[] seam) { // remove horizontal seam from current picture
		checkSeam(seam);
		int[][] newColor = new int[w][h - 1];
		for (int i = 0; i < w; i++) {
			System.arraycopy(color[i], 0, newColor[i], 0, seam[i]);
			if (seam[i] < h - 1)
				System.arraycopy(color[i], seam[i] + 1, newColor[i], seam[i], h - 1 - seam[i]);
		}
		h--;
		color = newColor;
		ready = false;
	}

	public void removeVerticalSeam(int[] seam) { // remove vertical seam from current picture
		transpose();
		removeHorizontalSeam(seam);
		transpose();
	}

}